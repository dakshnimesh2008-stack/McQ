BSTC MCQ Bank — 2,500 questions

5 files, 500 MCQs each: Hindi, English, Reasoning, Teaching Aptitude, Rajasthan + General GK. Sanskrit excluded.
Each JSON question has a stable ID, topic, difficulty, four options A-D, correct answer and explanation. CSV files are also included.

Quality note: This is a generated practice-bank draft. Review against the current official Rajasthan Pre D.El.Ed syllabus and authoritative sources before publishing. Some practice variations intentionally reinforce the same core concept. Static GK does not include current affairs.
