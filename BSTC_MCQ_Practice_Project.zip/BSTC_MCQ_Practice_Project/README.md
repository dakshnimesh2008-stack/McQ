# BSTC MCQ Practice — README (हिंदी + English)

Offline Android app (Kotlin · Jetpack Compose · Material 3) with 2,500 MCQs: Hindi, English, Reasoning, Teaching Aptitude, Rajasthan + General GK.

> **Honest status / ईमानदार स्थिति:** The code was written and checked by hand and with structural checks, but it has **not been compiled yet** (no Android SDK/internet was available where it was created). The first GitHub Actions run is the real compile test. If it fails, open the red step, copy the first `e:` error line and send it to me to fix.
> कोड अभी तक कंपाइल नहीं हुआ है। पहला GitHub Actions रन ही असली टेस्ट है। फेल हो तो पहली `e:` वाली error लाइन भेज दें।

---

## 1) GitHub पर APK बनाने के स्टेप / Steps

**Step 1 — Repository बनाएँ / Create a repository**
GitHub → **New repository** → name e.g. `bstc-mcq-app` → *Add a README file* ON → **Create repository**.

**Step 2 — पहले `build.yml` डालें / Add `build.yml` FIRST**
Repository page → **Add file → Create new file**. In the file-name box type exactly:

```
.github/workflows/build.yml
```
(typing `/` creates the folders). Paste the full contents of the separate **build.yml** file → **Commit changes**.

*(या: Add file → Upload files से `build.yml` को `.github/workflows/` फ़ोल्डर संरचना में डालना मुश्किल है, इसलिए "Create new file" तरीका इस्तेमाल करें।)*

**Step 3 — ZIP अपलोड करें / Upload the ZIP (do NOT extract)**
Repository root → **Add file → Upload files** → drag `BSTC_MCQ_Practice_Project.zip` (the ZIP itself, not its contents) → **Commit changes**.
The ZIP must sit in the repository **root**, not inside a folder.

**Step 4 — Build अपने-आप शुरू होगा / The build starts automatically**
Open the **Actions** tab. A run named **Build BSTC MCQ Practice APK** starts because a `.zip` was pushed. It takes ~5–10 minutes the first time.
If it did not start: Actions → *Build BSTC MCQ Practice APK* → **Run workflow** (green button).

**Step 5 — APK डाउनलोड करें / Download the APK**
Actions → click the finished (green ✔) run → scroll to **Artifacts** → click **BSTC-MCQ-Practice-debug-apk** → a ZIP downloads → unzip it → `BSTC-MCQ-Practice-debug.apk`.

**Step 6 — फ़ोन में इंस्टॉल / Install**
Copy the APK to your phone, open it, allow "Install unknown apps" for your file manager/browser when asked, install. (It is a *debug* APK, signed with Android's debug key — fine for personal use.)

---

## 2) What the workflow does
1. Finds the newest `.zip` in the repo that contains `settings.gradle(.kts)` (the data-only ZIP inside `data_source/` is ignored automatically).
2. Unzips it into `build_workspace/` and finds the Gradle project, even if the ZIP has a top-level folder.
3. Sets up JDK 17 and Gradle 8.9, accepts Android SDK licences.
4. Runs `assembleDebug` (uses the project's `gradlew` only if it is complete; otherwise the Gradle 8.9 installed by the workflow).
5. Uploads the APK as an artifact; on failure prints the project tree and environment.

**GitHub limitations (honest notes)**
- GitHub never runs a workflow that is only stored inside an uploaded ZIP, so `build.yml` must be added to the repo as a normal file first (Step 2). The ZIP in this package also contains a copy, but that copy is only a backup.
- The browser upload limit is 25 MB per file; this ZIP is far smaller.
- Artifacts are kept 30 days.
- `gradle-wrapper.jar` is not included (it can't be downloaded offline); the workflow does not need it.

## 3) Project layout
- `app/src/main/java/com/bstc/mcq/` – Kotlin source (Compose UI, test engine, local storage)
- `app/src/main/assets/mcq/` – the 5 original JSON question files (unchanged)
- `data_source/` – original ZIP, CSV files and the data README (for future updates)
- `tools/validate_data.py` – regenerates `DATA_VALIDATION_REPORT.md`
- Launcher icon: your image → `res/drawable-nodpi/ic_launcher_foreground.png` (adaptive) + legacy `mipmap-*` PNGs

## 4) Updating questions
Replace the JSON files in `app/src/main/assets/mcq/` (same structure, same file names), run `python3 tools/validate_data.py`, rebuild. Invalid or exact-duplicate records are skipped automatically by the app.

## 5) Notes on behaviour
- Score = +1 per correct answer, no negative marking. Bookmarks, wrong-question list, results (detailed review for latest 20 tests), stats, streak and an unfinished test are stored only on the phone.
- Wrong questions and statistics are recorded when a test is **submitted**.
- Question bank is a generated practice draft — verify against the official syllabus.
