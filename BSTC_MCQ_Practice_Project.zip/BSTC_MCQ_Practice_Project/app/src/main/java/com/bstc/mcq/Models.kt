package com.bstc.mcq

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Translate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class Subject(
    val key: String,
    val file: String,
    val en: String,
    val hi: String,
    val color: Color,
    val icon: ImageVector
) {
    HINDI("hindi", "hindi_500.json", "Hindi", "हिंदी", Color(0xFFE91E63), Icons.Filled.Translate),
    ENGLISH("english", "english_500.json", "English", "अंग्रेज़ी", Color(0xFF2196F3), Icons.Filled.MenuBook),
    REASONING("reasoning", "reasoning_500.json", "Reasoning", "तर्कशक्ति", Color(0xFF2E9E4F), Icons.Filled.Psychology),
    TEACHING("teaching", "teaching_aptitude_500.json", "Teaching Aptitude", "शिक्षण अभियोग्यता", Color(0xFFF2A100), Icons.Filled.School),
    GK("gk", "rajasthan_general_gk_500.json", "Rajasthan GK", "राजस्थान + सामान्य ज्ञान", Color(0xFF8E24AA), Icons.Filled.Map);

    companion object {
        fun fromKey(k: String): Subject? = values().firstOrNull { it.key == k }
    }
}

enum class Diff(val en: String) {
    EASY("Easy"), MEDIUM("Medium"), HARD("Hard");

    companion object {
        fun parse(s: String): Diff = when (s.trim().lowercase()) {
            "आसान", "easy" -> EASY
            "कठिन", "hard", "difficult" -> HARD
            else -> MEDIUM
        }
    }
}

enum class Style(val label: String, val desc: String) {
    CLASSIC("Classic Exam", "One question, palette, mark for review"),
    CARD("Card Mode", "Beautiful animated cards, one at a time"),
    RAPID("Rapid Fire", "Big text, fast taps, minimal screen"),
    PAPER("Question Paper", "All questions in one scrollable paper"),
    SWIPE("Swipe Practice", "Swipe or tap to move between cards")
}

enum class Distribution(val label: String) {
    EQUAL("Equal"), RANDOM("Random"), PROPORTIONAL("Proportional")
}

enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

enum class Source { NORMAL, BOOKMARKS, WRONG, IDS }

enum class SetupMode(val label: String) {
    SINGLE("Single"), MULTI("Multiple"), MIXED("All Mixed"), CUSTOM("Custom")
}

data class Question(
    val id: String,
    val subject: Subject,
    val topic: String,
    val diff: Diff,
    val text: String,
    val options: List<String>,   // index 0..3 == A..D in the ORIGINAL data
    val correct: Int,            // index into options
    val answerText: String,
    val explanation: String
)

/** A question prepared for display. order[i] = original option index shown at position i. */
data class PQ(val q: Question, val order: List<Int>)

data class TestConfig(
    val title: String,
    val subjects: Set<Subject>,
    val topics: Set<String>,
    val count: Int,              // 0 = all available
    val difficulty: Diff?,       // null = mixed
    val distribution: Distribution,
    val timerMin: Int,           // 0 = off
    val shuffleQ: Boolean,
    val shuffleOpts: Boolean,
    val style: Style,
    val instant: Boolean,
    val source: Source = Source.NORMAL
)

data class Settings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val style: Style = Style.CLASSIC,
    val instant: Boolean = true,
    val count: Int = 20,
    val timerMin: Int = 0,
    val sound: Boolean = true,
    val haptic: Boolean = true,
    val shuffleQ: Boolean = true,
    val shuffleOpts: Boolean = true
)

data class SubjectResult(val key: String, val total: Int, val attempted: Int, val correct: Int)
data class ResultItem(val qid: String, val order: List<Int>, val selected: Int, val marked: Boolean)

data class ResultRecord(
    val id: Long,
    val title: String,
    val total: Int,
    val attempted: Int,
    val correct: Int,
    val seconds: Int,
    val subjects: List<SubjectResult>,
    val items: List<ResultItem>
) {
    val wrong get() = attempted - correct
    val unattempted get() = total - attempted
    val accuracy get() = if (attempted == 0) 0 else (correct * 100f / attempted).toInt()
    val scorePct get() = if (total == 0) 0 else (correct * 100f / total).toInt()
}

data class Stats(
    val tests: Int = 0,
    val attempted: Int = 0,
    val correct: Int = 0,
    val corrected: Int = 0,
    val perSubject: Map<String, Pair<Int, Int>> = emptyMap() // key -> (attempted, correct)
) {
    val wrong get() = attempted - correct
    val accuracy get() = if (attempted == 0) 0 else (correct * 100f / attempted).toInt()
}

data class DataReport(
    val loaded: Int,
    val skipped: Int,
    val duplicates: Int,
    val perSubject: Map<Subject, Int>
)
