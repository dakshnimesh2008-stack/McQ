package com.bstc.mcq

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFC857)
val GoodGreen = Color(0xFF1B7F3B)
val BadRed = Color(0xFFB3261E)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5B9BFF),
    onPrimary = Color(0xFF00102B),
    primaryContainer = Color(0xFF123A7A),
    onPrimaryContainer = Color(0xFFDCE8FF),
    secondary = Gold,
    onSecondary = Color(0xFF241A00),
    secondaryContainer = Color(0xFF4A3900),
    onSecondaryContainer = Color(0xFFFFE9B0),
    background = Color(0xFF000000),
    onBackground = Color(0xFFEAEFFA),
    surface = Color(0xFF0A0E17),
    onSurface = Color(0xFFEAEFFA),
    surfaceVariant = Color(0xFF151C2B),
    onSurfaceVariant = Color(0xFFB4BED2),
    outline = Color(0xFF3A4660),
    error = Color(0xFFFF6B63)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE8FF),
    onPrimaryContainer = Color(0xFF0B2A66),
    secondary = Color(0xFFB7791F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFEBC2),
    onSecondaryContainer = Color(0xFF4A3200),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF111827),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFEFF4FD),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFC3CEE3),
    error = Color(0xFFB3261E)
)

@Composable
fun isDarkFor(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.DARK -> true
    ThemeMode.LIGHT -> false
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
}

@Composable
fun BstcTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
