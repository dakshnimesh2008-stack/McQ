package com.bstc.mcq

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------- feedback (haptics + sound) ----------------
class Feedback(private val haptic: HapticFeedback, private val s: Settings) {
    private var tone: ToneGenerator? = null

    private fun beep(type: Int, ms: Int) {
        if (!s.sound) return
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 45)
            tone?.startTone(type, ms)
        } catch (e: Throwable) { }
    }

    fun tap() { if (s.haptic) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    fun correct() {
        if (s.haptic) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        beep(ToneGenerator.TONE_PROP_ACK, 120)
    }
    fun wrong() {
        if (s.haptic) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        beep(ToneGenerator.TONE_PROP_NACK, 160)
    }
    fun release() { try { tone?.release() } catch (e: Throwable) { }; tone = null }
}

@Composable
fun rememberFeedback(s: Settings): Feedback {
    val h = LocalHapticFeedback.current
    val f = remember(s.sound, s.haptic) { Feedback(h, s) }
    DisposableEffect(f) { onDispose { f.release() } }
    return f
}

// ---------------- generic bits ----------------
@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, actions: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        } else Spacer(Modifier.width(12.dp))
        Text(
            title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f), maxLines = 1
        )
        actions()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary, modifier = modifier.padding(top = 18.dp, bottom = 8.dp)
    )
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, accent: Color = MaterialTheme.colorScheme.primary) {
    Card(
        modifier, shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.Start) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = accent)
            Spacer(Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ProgressRing(fraction: Float, label: String, sub: String, size: Int = 150, color: Color = MaterialTheme.colorScheme.primary) {
    val anim by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(900), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceVariant
    val gold = MaterialTheme.colorScheme.secondary
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxHeight().fillMaxWidth()) {
            val sw = this.size.minDimension * 0.11f
            val inset = sw / 2
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(
                if (fraction >= 0.75f) gold else color, -90f, 360f * anim, false, Offset(inset, inset), arcSize,
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = (size / 5).sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Simple vertical bar chart. values are 0..100. */
@Composable
fun BarChart(labels: List<String>, values: List<Int>, colors: List<Color>, height: Int = 150) {
    val onSv = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth().height((height + 36).dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom
    ) {
        labels.forEachIndexed { i, l ->
            val v by animateFloatAsState(values[i] / 100f, tween(800), label = "bar")
            Column(Modifier.weight(1f).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${values[i]}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Box(Modifier.height(height.dp).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.fillMaxWidth(0.62f).fillMaxHeight(v.coerceAtLeast(0.02f))
                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)).background(colors[i % colors.size])
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(l, style = MaterialTheme.typography.labelSmall, color = onSv, maxLines = 1, textAlign = TextAlign.Center)
            }
        }
    }
}

// ---------------- option row ----------------
enum class OptState { NORMAL, SELECTED, CORRECT, WRONG, DIM }

@Composable
fun OptionRow(letter: String, text: String, state: OptState, enabled: Boolean, big: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        when (state) {
            OptState.NORMAL -> cs.surfaceVariant
            OptState.SELECTED -> cs.primaryContainer
            OptState.CORRECT -> GoodGreen
            OptState.WRONG -> BadRed
            OptState.DIM -> cs.surfaceVariant.copy(alpha = 0.45f)
        }, tween(220), label = "optbg"
    )
    val scale by animateFloatAsState(
        if (state == OptState.SELECTED || state == OptState.CORRECT || state == OptState.WRONG) 1.015f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "optscale"
    )
    val fg = when (state) {
        OptState.CORRECT, OptState.WRONG -> Color.White
        OptState.SELECTED -> cs.onPrimaryContainer
        else -> cs.onSurface
    }
    val border = if (state == OptState.SELECTED) BorderStroke(2.dp, cs.primary) else BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
    Row(
        Modifier.fillMaxWidth().scale(scale).clip(RoundedCornerShape(16.dp)).background(bg)
            .border(border, RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = if (big) 18.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(if (big) 36.dp else 30.dp).clip(CircleShape)
                .background(fg.copy(alpha = 0.14f)), contentAlignment = Alignment.Center
        ) { Text(letter, color = fg, fontWeight = FontWeight.Bold, fontSize = if (big) 16.sp else 14.sp) }
        Spacer(Modifier.width(12.dp))
        Text(text, color = fg, modifier = Modifier.weight(1f), fontSize = if (big) 19.sp else 16.sp, lineHeight = if (big) 26.sp else 22.sp)
        if (state == OptState.CORRECT) Icon(Icons.Filled.Check, null, tint = Color.White)
        if (state == OptState.WRONG) Icon(Icons.Filled.Close, null, tint = Color.White)
    }
}

@Composable
fun ExplanationCard(q: Question) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lightbulb, null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Correct answer: ${q.answerText}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            if (q.explanation.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(q.explanation, color = MaterialTheme.colorScheme.onSecondaryContainer, fontSize = 15.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
fun SubjectTag(q: Question) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(q.subject.color))
        Spacer(Modifier.width(6.dp))
        Text(
            "${q.subject.en} · ${q.topic}", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
        )
    }
}

/** Question text + the four options. Handles shuffled order and instant/exam feedback. */
@Composable
fun QuestionContent(
    pq: PQ, session: LiveSession, vm: AppViewModel, fb: Feedback,
    textSize: TextUnit = 19.sp, big: Boolean = false, onPicked: (Int) -> Unit = {}
) {
    val sel = session.answers[pq.q.id]
    val instant = session.cfg.instant
    val revealed = instant && sel != null
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SubjectTag(pq.q)
        Text(pq.q.text, fontSize = textSize, fontWeight = FontWeight.SemiBold, lineHeight = textSize * 1.4f)
        Spacer(Modifier.height(2.dp))
        pq.order.forEachIndexed { i, orig ->
            val st = when {
                revealed -> if (orig == pq.q.correct) OptState.CORRECT else if (orig == sel) OptState.WRONG else OptState.DIM
                sel == orig -> OptState.SELECTED
                else -> OptState.NORMAL
            }
            OptionRow(('A' + i).toString(), pq.q.options[orig], st, enabled = !revealed, big = big) {
                if (instant) { if (orig == pq.q.correct) fb.correct() else fb.wrong() } else fb.tap()
                vm.answer(pq.q.id, orig)
                onPicked(orig)
            }
        }
        if (revealed) ExplanationCard(pq.q)
    }
}
