package com.bstc.mcq

import android.content.Context
import org.json.JSONObject

/** Loads and validates the offline MCQ bank from assets/mcq. Invalid / duplicate records are skipped, never invented. */
object Bank {
    var all: List<Question> = emptyList()
        private set
    var byId: Map<String, Question> = emptyMap()
        private set
    var report: DataReport = DataReport(0, 0, 0, emptyMap())
        private set
    private var loaded = false

    fun bySubject(s: Subject): List<Question> = all.filter { it.subject == s }

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        val out = ArrayList<Question>()
        val seenIds = HashSet<String>()
        val seenKeys = HashSet<String>()
        var skipped = 0
        var dups = 0
        for (subject in Subject.values()) {
            try {
                val text = ctx.assets.open("mcq/" + subject.file).bufferedReader(Charsets.UTF_8).use { it.readText() }
                val arr = JSONObject(text).getJSONArray("questions")
                for (i in 0 until arr.length()) {
                    try {
                        val o = arr.getJSONObject(i)
                        val id = o.optString("id").trim()
                        val qt = o.optString("question").trim()
                        val opts = o.optJSONArray("options")
                        if (id.isEmpty() || qt.isEmpty() || opts == null) { skipped++; continue }
                        val map = HashMap<String, String>()
                        for (k in 0 until opts.length()) {
                            val oo = opts.getJSONObject(k)
                            map[oo.optString("value").trim().uppercase()] = oo.optString("text").trim()
                        }
                        val letters = listOf("A", "B", "C", "D")
                        if (letters.any { map[it].isNullOrEmpty() }) { skipped++; continue }
                        val ci = letters.indexOf(o.optString("correct_answer").trim().uppercase())
                        if (ci < 0) { skipped++; continue }
                        val optList = letters.map { map[it]!! }
                        if (optList.toSet().size < 4) { skipped++; continue }
                        if (!seenIds.add(id)) { dups++; continue }
                        val key = qt + "|" + optList.sorted().joinToString("|")
                        if (!seenKeys.add(key)) { dups++; continue }
                        val at = o.optString("answer_text").trim().ifEmpty { optList[ci] }
                        out.add(
                            Question(
                                id, subject, o.optString("topic").trim().ifEmpty { "General" },
                                Diff.parse(o.optString("difficulty")), qt, optList, ci, at,
                                o.optString("explanation").trim()
                            )
                        )
                    } catch (e: Exception) {
                        skipped++
                    }
                }
            } catch (e: Exception) {
                // missing/corrupt file: subject simply has zero questions; app keeps running
            }
        }
        all = out
        byId = out.associateBy { it.id }
        report = DataReport(out.size, skipped, dups, Subject.values().associateWith { s -> out.count { it.subject == s } })
        loaded = true
    }
}
