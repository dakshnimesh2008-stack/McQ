package com.bstc.mcq

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PracticeScreen(vm: AppViewModel) {
    val s = vm.session
    if (s == null) {
        // Session already submitted/discarded (e.g. during the exit animation): draw nothing.
        Box(Modifier.fillMaxSize())
        return
    }
    val fb = rememberFeedback(vm.settings)
    var showExit by remember { mutableStateOf(false) }
    var showSubmit by remember { mutableStateOf(false) }

    BackHandler { showExit = true }

    // one-second ticker; auto-submits when the timer runs out
    LaunchedEffect(s) {
        while (true) {
            delay(1000)
            if (vm.tick()) { vm.submit(); break }
        }
    }

    Column(Modifier.fillMaxSize()) {
        when (s.cfg.style) {
            Style.CLASSIC -> ClassicMode(vm, s, fb, { showExit = true }, { showSubmit = true })
            Style.CARD -> CardMode(vm, s, fb, { showExit = true }, { showSubmit = true })
            Style.RAPID -> RapidMode(vm, s, fb, { showExit = true }, { showSubmit = true })
            Style.PAPER -> PaperMode(vm, s, fb, { showExit = true }, { showSubmit = true })
            Style.SWIPE -> SwipeMode(vm, s, fb, { showExit = true }, { showSubmit = true })
        }
    }

    if (showSubmit) {
        val answered = s.answers.size
        AlertDialog(
            onDismissRequest = { showSubmit = false },
            title = { Text("Submit test?") },
            text = {
                Text(
                    "Answered: $answered of ${s.items.size}\nUnanswered: ${s.items.size - answered}\n" +
                        "Marked for review: ${s.marked.size}\n\nYou cannot change answers after submitting."
                )
            },
            confirmButton = { TextButton(onClick = { showSubmit = false; vm.submit() }) { Text("Submit") } },
            dismissButton = { TextButton(onClick = { showSubmit = false }) { Text("Keep practising") } }
        )
    }
    if (showExit) {
        AlertDialog(
            onDismissRequest = { showExit = false },
            title = { Text("Leave this test?") },
            text = { Text("Your progress is saved on this device. You can resume it from the home screen, or submit now.") },
            confirmButton = { TextButton(onClick = { showExit = false; vm.saveNow(); vm.goHome() }) { Text("Save & exit") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { showExit = false }) { Text("Cancel") }
                    TextButton(onClick = { showExit = false; showSubmit = true }) { Text("Submit") }
                }
            }
        )
    }
}

// ---------------- shared pieces ----------------
@Composable
private fun TimerChip(s: LiveSession) {
    val limited = s.cfg.timerMin > 0
    val value = if (limited) s.cfg.timerMin * 60 - s.elapsed else s.elapsed
    val low = limited && value <= 60
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(
            if (low) MaterialTheme.colorScheme.error.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant
        ).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Timer, null, Modifier.size(16.dp), tint = if (low) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(4.dp))
        Text(Engine.fmtTime(value), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (low) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun PracticeTopBar(vm: AppViewModel, s: LiveSession, title: String, onExit: () -> Unit, showBookmark: Boolean = true) {
    val pq = s.items[s.index]
    ScreenHeader(title, onExit) {
        TimerChip(s)
        if (showBookmark) {
            val saved = vm.bookmarks.contains(pq.q.id)
            IconButton(onClick = { vm.toggleBookmark(pq.q.id) }) {
                Icon(
                    if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, "Bookmark",
                    tint = if (saved) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun NavBar(
    s: LiveSession, vm: AppViewModel, onSubmit: () -> Unit, extra: @Composable () -> Unit = {},
    onNext: (() -> Unit)? = null, onPrev: (() -> Unit)? = null
) {
    val last = s.index == s.items.size - 1
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(
            onClick = { if (onPrev != null) onPrev() else vm.goto(s.index - 1) }, enabled = s.index > 0,
            shape = RoundedCornerShape(14.dp)
        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(18.dp)); Text(" Prev") }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { extra() }
        if (last) {
            Button(onClick = onSubmit, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary, contentColor = MaterialTheme.colorScheme.onSecondary)) { Text("Submit") }
        } else {
            Button(onClick = { if (onNext != null) onNext() else vm.goto(s.index + 1) }, shape = RoundedCornerShape(14.dp)) {
                Text("Next "); Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp))
            }
        }
    }
}

// ---------------- Style 1: Classic exam ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ColumnScope.ClassicMode(vm: AppViewModel, s: LiveSession, fb: Feedback, onExit: () -> Unit, onSubmit: () -> Unit) {
    var showPalette by remember { mutableStateOf(false) }
    val pq = s.items[s.index]
    PracticeTopBar(vm, s, "Q ${s.index + 1} / ${s.items.size}", onExit)
    LinearProgressIndicator(progress = { (s.answers.size.toFloat() / s.items.size) }, Modifier.fillMaxWidth().height(4.dp))
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
        QuestionContent(pq, s, vm, fb)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val marked = s.marked.contains(pq.q.id)
            OutlinedButton(onClick = { fb.tap(); vm.toggleMark(pq.q.id) }, shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Filled.Flag, null, Modifier.size(16.dp), tint = if (marked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface)
                Text(if (marked) " Marked" else " Mark for review")
            }
            if (!s.cfg.instant && s.answers.containsKey(pq.q.id)) {
                TextButton(onClick = { vm.clearAnswer(pq.q.id) }) { Text("Clear answer") }
            }
        }
    }
    NavBar(s, vm, onSubmit, extra = {
        IconButton(onClick = { showPalette = true }) { Icon(Icons.Filled.GridView, "Question palette", tint = MaterialTheme.colorScheme.primary) }
    })
    if (showPalette) {
        ModalBottomSheet(onDismissRequest = { showPalette = false }) {
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                Text("Question palette", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "Answered ${s.answers.size} · Marked ${s.marked.size} · Unanswered ${s.items.size - s.answers.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(
                    GridCells.Adaptive(52.dp), Modifier.heightIn(max = 360.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(s.items) { i, item ->
                        val answered = s.answers.containsKey(item.q.id)
                        val mk = s.marked.contains(item.q.id)
                        val bg = when {
                            mk -> MaterialTheme.colorScheme.secondary
                            answered -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        val fg = if (mk || answered) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurface
                        Box(
                            Modifier.size(48.dp).clip(CircleShape).background(bg)
                                .then(if (i == s.index) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                .clickable { vm.goto(i); showPalette = false },
                            contentAlignment = Alignment.Center
                        ) { Text("${i + 1}", color = fg, fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Blue = answered · Gold = marked for review · Grey = not answered", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------------- Style 2: Card mode ----------------
@Composable
private fun ColumnScope.CardMode(vm: AppViewModel, s: LiveSession, fb: Feedback, onExit: () -> Unit, onSubmit: () -> Unit) {
    PracticeTopBar(vm, s, "Card Practice", onExit)
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(progress = { (s.index + 1f) / s.items.size }, Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(10.dp))
            Text("${s.index + 1}/${s.items.size}", fontWeight = FontWeight.Bold)
        }
    }
    Spacer(Modifier.height(10.dp))
    AnimatedContent(
        targetState = s.index, modifier = Modifier.weight(1f),
        transitionSpec = {
            val dir = if (targetState > initialState) 1 else -1
            (slideInHorizontally(tween(320)) { it * dir } + fadeIn(tween(320))) togetherWith
                (slideOutHorizontally(tween(320)) { -it * dir } + fadeOut(tween(200))) using SizeTransform(clip = false)
        }, label = "cards"
    ) { idx ->
        val pq = s.items[idx.coerceIn(0, s.items.size - 1)]
        Card(
            Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 4.dp), shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp)) { QuestionContent(pq, s, vm, fb) }
        }
    }
    NavBar(s, vm, onSubmit)
}

// ---------------- Style 3: Rapid fire ----------------
@Composable
private fun ColumnScope.RapidMode(vm: AppViewModel, s: LiveSession, fb: Feedback, onExit: () -> Unit, onSubmit: () -> Unit) {
    val scope = rememberCoroutineScope()
    val pq = s.items[s.index]
    val last = s.index == s.items.size - 1
    ScreenHeader("${s.index + 1} / ${s.items.size}", onExit) { TimerChip(s) }
    LinearProgressIndicator(progress = { (s.index + 1f) / s.items.size }, Modifier.fillMaxWidth().height(3.dp))
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
        QuestionContent(pq, s, vm, fb, textSize = 24.sp, big = true, onPicked = {
            if (!s.cfg.instant && !last) {
                val at = s.index
                scope.launch { delay(260); if (s.index == at) vm.goto(at + 1) }
            }
        })
    }
    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = { vm.goto(s.index - 1) }, enabled = s.index > 0, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Back") }
        if (last) {
            Button(onClick = onSubmit, modifier = Modifier.weight(2f), shape = RoundedCornerShape(14.dp)) { Text("Finish") }
        } else {
            Button(onClick = { vm.goto(s.index + 1) }, modifier = Modifier.weight(2f), shape = RoundedCornerShape(14.dp)) {
                Text(if (s.answers.containsKey(pq.q.id)) "Next" else "Skip")
            }
        }
    }
}

// ---------------- Style 4: Question paper ----------------
@Composable
private fun ColumnScope.PaperMode(vm: AppViewModel, s: LiveSession, fb: Feedback, onExit: () -> Unit, onSubmit: () -> Unit) {
    ScreenHeader("Question Paper", onExit) { TimerChip(s) }
    Text(
        "Answered ${s.answers.size} of ${s.items.size}", Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
    )
    LinearProgressIndicator(progress = { s.answers.size.toFloat() / s.items.size }, Modifier.fillMaxWidth().height(4.dp))
    LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(s.items, key = { _, it -> it.q.id }) { i, pq ->
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 10.dp, vertical = 4.dp)) {
                            Text("Q${i + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Spacer(Modifier.weight(1f))
                        val saved = vm.bookmarks.contains(pq.q.id)
                        IconButton(onClick = { vm.toggleBookmark(pq.q.id) }) {
                            Icon(if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, "Bookmark", tint = if (saved) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    QuestionContent(pq, s, vm, fb, textSize = 17.sp)
                    if (!s.cfg.instant && s.answers.containsKey(pq.q.id)) {
                        TextButton(onClick = { vm.clearAnswer(pq.q.id) }) { Text("Clear answer") }
                    }
                }
            }
        }
    }
    Button(onClick = onSubmit, modifier = Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(16.dp)) { Text("Submit all answers") }
}

// ---------------- Style 5: Swipe ----------------
@Composable
private fun ColumnScope.SwipeMode(vm: AppViewModel, s: LiveSession, fb: Feedback, onExit: () -> Unit, onSubmit: () -> Unit) {
    val pager = rememberPagerState(initialPage = s.index) { s.items.size }
    val scope = rememberCoroutineScope()
    LaunchedEffect(pager.currentPage) { if (pager.currentPage != s.index) vm.goto(pager.currentPage) }
    LaunchedEffect(s.index) { if (pager.currentPage != s.index) pager.animateScrollToPage(s.index) }
    PracticeTopBar(vm, s, "Swipe Practice", onExit)
    Text(
        "Question ${s.index + 1} of ${s.items.size}  ·  swipe or use the buttons", Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
    )
    Spacer(Modifier.height(6.dp))
    HorizontalPager(pager, Modifier.weight(1f), pageSpacing = 12.dp, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp)) { page ->
        val pq = s.items[page]
        Card(
            Modifier.fillMaxSize().padding(vertical = 4.dp), shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp)) { QuestionContent(pq, s, vm, fb) }
        }
    }
    NavBar(s, vm, onSubmit, onNext = { scope.launch { pager.animateScrollToPage((s.index + 1).coerceAtMost(s.items.size - 1)) } },
        onPrev = { scope.launch { pager.animateScrollToPage((s.index - 1).coerceAtLeast(0)) } })
}
