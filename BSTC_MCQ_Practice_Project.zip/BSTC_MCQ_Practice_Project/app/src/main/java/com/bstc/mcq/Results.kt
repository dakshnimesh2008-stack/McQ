package com.bstc.mcq

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

private fun fmtDate(t: Long): String = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(t))

@Composable
fun ResultScreen(vm: AppViewModel, id: Long) {
    val cs = MaterialTheme.colorScheme
    val r = vm.results.firstOrNull { it.id == id }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Result", { vm.goHome() })
        if (r == null) {
            Text("This result is no longer available.", Modifier.padding(16.dp)); return@Column
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(r.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(fmtDate(r.id), color = cs.onSurfaceVariant, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            ProgressRing(r.scorePct / 100f, "${r.correct}/${r.total}", "Score · ${r.scorePct}%", 170)
            Spacer(Modifier.height(16.dp))
            val tiles = listOf(
                "Total questions" to "${r.total}", "Attempted" to "${r.attempted}", "Correct" to "${r.correct}",
                "Incorrect" to "${r.wrong}", "Unattempted" to "${r.unattempted}", "Accuracy" to "${r.accuracy}%",
                "Score" to "${r.correct} / ${r.total}", "Time taken" to Engine.fmtTime(r.seconds)
            )
            tiles.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (l, v) ->
                        StatTile(
                            l, v, Modifier.weight(1f),
                            accent = when (l) { "Correct" -> GoodGreen; "Incorrect" -> cs.error; else -> cs.primary }
                        )
                    }
                }
            }
            Text("Scoring: +1 for each correct answer, no negative marking.", fontSize = 12.sp, color = cs.onSurfaceVariant)
            SectionTitle("Subject-wise performance", Modifier.align(Alignment.Start))
            r.subjects.forEach { sr ->
                val s = Subject.fromKey(sr.key) ?: return@forEach
                val acc = if (sr.attempted == 0) 0 else sr.correct * 100 / sr.attempted
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row {
                        Text(s.en, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${sr.correct}/${sr.total} correct · $acc% acc", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { if (sr.total == 0) 0f else sr.correct.toFloat() / sr.total },
                        Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)), color = s.color, trackColor = cs.surfaceVariant
                    )
                }
            }
        }
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.push(Screen.Review(r.id)) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Review answers") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val wrongIds = r.items.filter { it.selected >= 0 && Bank.byId[it.qid]?.correct != it.selected }.map { it.qid }
                OutlinedButton(
                    onClick = {
                        vm.push(Screen.Setup("Wrong from this test", SetupMode.MIXED, Subject.values().toSet(), Source.IDS, 0, 0, true, null, wrongIds))
                    },
                    enabled = wrongIds.isNotEmpty(), modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)
                ) { Text("Practice mistakes") }
                OutlinedButton(onClick = { vm.goHome() }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Home") }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReviewScreen(vm: AppViewModel, id: Long) {
    val cs = MaterialTheme.colorScheme
    val r = vm.results.firstOrNull { it.id == id }
    var filter by remember { mutableStateOf(0) } // 0 all 1 wrong 2 correct 3 unattempted
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Answer review", { vm.pop() })
        if (r == null || r.items.isEmpty()) {
            Text(
                "Detailed review is kept for your latest 20 tests. This test's per-question details are not stored.",
                Modifier.padding(16.dp), color = cs.onSurfaceVariant
            )
            return@Column
        }
        val rows = r.items.mapIndexedNotNull { i, it ->
            val q = Bank.byId[it.qid] ?: return@mapIndexedNotNull null
            Triple(i, q, it)
        }
        FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Incorrect", "Correct", "Unattempted").forEachIndexed { i, l ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(l) })
            }
        }
        val shown = rows.filter { (_, q, it) ->
            when (filter) {
                1 -> it.selected >= 0 && it.selected != q.correct
                2 -> it.selected == q.correct
                3 -> it.selected < 0
                else -> true
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(shown, key = { it.second.id }) { (i, q, it) ->
                val status = when {
                    it.selected < 0 -> "Unattempted"
                    it.selected == q.correct -> "Correct"
                    else -> "Incorrect"
                }
                val order = if (it.order.sorted() == listOf(0, 1, 2, 3)) it.order else listOf(0, 1, 2, 3)
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = cs.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Q${i + 1} · $status", fontWeight = FontWeight.Bold,
                                color = when (status) { "Correct" -> GoodGreen; "Incorrect" -> cs.error; else -> cs.onSurfaceVariant })
                            Spacer(Modifier.weight(1f))
                            val saved = vm.bookmarks.contains(q.id)
                            IconButton(onClick = { vm.toggleBookmark(q.id) }) {
                                Icon(if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, "Bookmark", tint = if (saved) cs.secondary else cs.onSurface)
                            }
                        }
                        SubjectTag(q)
                        Text(q.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp)
                        order.forEachIndexed { pos, orig ->
                            val st = when {
                                orig == q.correct -> OptState.CORRECT
                                orig == it.selected -> OptState.WRONG
                                else -> OptState.DIM
                            }
                            OptionRow(('A' + pos).toString(), q.options[orig], st, enabled = false) {}
                        }
                        if (it.selected < 0) Text("You did not attempt this question.", fontSize = 13.sp, color = cs.onSurfaceVariant)
                        ExplanationCard(q)
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Previous results", { vm.pop() })
        if (vm.results.isEmpty()) {
            EmptyState("No tests yet", "Finish a test and its result will appear here.")
            return@Column
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.results, key = { it.id }) { r ->
                Card(
                    Modifier.fillMaxWidth().clickable { vm.push(Screen.Result(r.id)) }, shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.Bold)
                            Text(fmtDate(r.id), fontSize = 12.sp, color = cs.onSurfaceVariant)
                            Text("${r.correct}/${r.total} correct · ${Engine.fmtTime(r.seconds)}", fontSize = 13.sp)
                        }
                        Text("${r.scorePct}%", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = if (r.scorePct >= 60) GoodGreen else cs.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyState(title: String, sub: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Bookmarks or Wrong-questions list (they behave the same). */
@Composable
fun QuestionListScreen(vm: AppViewModel, wrongList: Boolean) {
    val cs = MaterialTheme.colorScheme
    val ids = if (wrongList) vm.wrong else vm.bookmarks
    val qs = ids.mapNotNull { Bank.byId[it] }.sortedWith(compareBy({ it.subject.ordinal }, { it.id }))
    var open by remember { mutableStateOf(setOf<String>()) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (wrongList) "Wrong questions" else "Bookmarked questions", { vm.pop() })
        if (qs.isEmpty()) {
            EmptyState(
                if (wrongList) "No wrong questions" else "No bookmarks yet",
                if (wrongList) "Questions you answer incorrectly are saved here automatically after you submit a test."
                else "Tap the bookmark icon on any question to save it here."
            )
            return@Column
        }
        if (wrongList) {
            Text(
                "Mistakes fixed so far: ${vm.stats.corrected} · Still to fix: ${qs.size}",
                Modifier.padding(horizontal = 16.dp, vertical = 4.dp), color = cs.onSurfaceVariant, fontSize = 13.sp
            )
        }
        Button(
            onClick = {
                vm.push(Screen.Setup(if (wrongList) "Practice wrong questions" else "Practice bookmarks", SetupMode.MIXED, Subject.values().toSet(),
                    if (wrongList) Source.WRONG else Source.BOOKMARKS, 0, null, null, null))
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), shape = RoundedCornerShape(14.dp)
        ) { Text("Practice these ${qs.size} questions") }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(qs, key = { it.id }) { q ->
                val expanded = q.id in open
                Card(
                    Modifier.fillMaxWidth().clickable { open = if (expanded) open - q.id else open + q.id }, shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { SubjectTag(q) }
                            IconButton(onClick = { if (wrongList) vm.removeWrong(q.id) else vm.toggleBookmark(q.id) }) {
                                Icon(Icons.Filled.Delete, "Remove", tint = cs.onSurfaceVariant)
                            }
                        }
                        Text(q.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        if (expanded) {
                            q.options.forEachIndexed { i, o ->
                                OptionRow(('A' + i).toString(), o, if (i == q.correct) OptState.CORRECT else OptState.DIM, enabled = false) {}
                            }
                            ExplanationCard(q)
                        } else {
                            Text("Tap to show answer", fontSize = 12.sp, color = cs.primary)
                        }
                    }
                }
            }
        }
    }
}
