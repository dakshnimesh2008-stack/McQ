package com.bstc.mcq

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SetupScreen(vm: AppViewModel, p: Screen.Setup) {
    val cs = MaterialTheme.colorScheme
    val st = vm.settings
    var mode by remember { mutableStateOf(p.mode) }
    var subjects by remember { mutableStateOf(if (p.mode == SetupMode.SINGLE) p.subjects.take(1).toSet() else p.subjects) }
    var topics by remember { mutableStateOf(emptySet<String>()) }
    var diff by remember { mutableStateOf<Diff?>(null) }
    var count by remember { mutableStateOf(p.count ?: st.count) }
    var dist by remember { mutableStateOf(Distribution.EQUAL) }
    var timer by remember { mutableStateOf(p.timerMin ?: st.timerMin) }
    var shuffleQ by remember { mutableStateOf(st.shuffleQ) }
    var shuffleO by remember { mutableStateOf(st.shuffleOpts) }
    var style by remember { mutableStateOf(p.style ?: st.style) }
    var instant by remember { mutableStateOf(p.instant ?: st.instant) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmReplace by remember { mutableStateOf(false) }

    val base = remember(p.source, vm.bookmarks, vm.wrong, p.ids) { vm.poolFor(p.source, p.ids) }
    val activeSubjects = if (mode == SetupMode.MIXED) Subject.values().toSet() else subjects
    val availSubjects = Subject.values().filter { s -> base.any { it.subject == s } }
    val availTopics = base.filter { it.subject in activeSubjects }.map { it.topic }.distinct().sorted()
    val effTopics = topics.filter { it in availTopics }.toSet()
    val filtered = Engine.filterPool(base, activeSubjects, effTopics, diff)
    val requested = if (count == 0) filtered.size else count
    val effective = minOf(requested, filtered.size)

    fun startNow() {
        val title = when {
            p.source == Source.BOOKMARKS -> "Bookmarked Questions"
            p.source == Source.WRONG -> "Wrong Questions"
            p.source == Source.IDS -> p.title
            mode == SetupMode.MIXED -> "Mixed Mock Test"
            activeSubjects.size == 1 -> activeSubjects.first().en
            mode == SetupMode.CUSTOM -> "Custom Test"
            else -> "Mixed (${activeSubjects.size} subjects)"
        }
        val cfg = TestConfig(title, activeSubjects, effTopics, count, diff, dist, timer, shuffleQ, shuffleO, style, instant, p.source)
        error = vm.start(cfg, p.ids)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(p.title.ifBlank { "Practice setup" }, { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            if (p.source == Source.NORMAL) {
                SectionTitle("Mode", Modifier)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SetupMode.values().forEach { m ->
                        FilterChip(selected = mode == m, onClick = {
                            mode = m
                            if (m == SetupMode.SINGLE && subjects.size != 1) subjects = setOf(subjects.firstOrNull() ?: Subject.HINDI)
                            if (m != SetupMode.SINGLE && subjects.isEmpty()) subjects = Subject.values().toSet()
                        }, label = { Text(m.label) })
                    }
                }
            }
            SectionTitle("Subjects")
            if (mode == SetupMode.MIXED) {
                Text("All ${availSubjects.size} subjects are mixed together.", color = cs.onSurfaceVariant)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    availSubjects.forEach { s ->
                        FilterChip(selected = s in subjects, onClick = {
                            subjects = if (mode == SetupMode.SINGLE) setOf(s)
                            else if (s in subjects) { if (subjects.size > 1) subjects - s else subjects } else subjects + s
                        }, label = { Text(s.en) })
                    }
                }
                if (mode != SetupMode.SINGLE) {
                    Row {
                        TextButton(onClick = { subjects = availSubjects.toSet() }) { Text("Select all") }
                    }
                }
            }
            if (activeSubjects.size > 1) {
                SectionTitle("Distribution across subjects")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Distribution.values().forEach { d -> FilterChip(selected = dist == d, onClick = { dist = d }, label = { Text(d.label) }) }
                }
                Text(
                    when (dist) {
                        Distribution.EQUAL -> "Same number of questions from each subject."
                        Distribution.RANDOM -> "Questions are drawn at random from the whole pool."
                        Distribution.PROPORTIONAL -> "More questions from subjects that have more available."
                    }, fontSize = 12.sp, color = cs.onSurfaceVariant
                )
            }
            SectionTitle("Number of questions")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10, 20, 25, 30, 50, 100, 0).forEach { n ->
                    FilterChip(selected = count == n, onClick = { count = n }, label = { Text(if (n == 0) "All available" else "$n") })
                }
            }
            Text(
                if (filtered.isEmpty()) "No questions match this selection." else "${filtered.size} available · this test will have $effective questions",
                Modifier.padding(top = 6.dp), fontSize = 13.sp,
                color = if (filtered.isEmpty()) cs.error else cs.onSurfaceVariant, fontWeight = FontWeight.Medium
            )
            if (filtered.isNotEmpty() && count != 0 && count > filtered.size) {
                Text("Only ${filtered.size} questions are available, so the test will be shorter.", fontSize = 12.sp, color = cs.secondary)
            }
            if (filtered.isNotEmpty() && dist == Distribution.EQUAL && activeSubjects.size > 1) {
                val share = (effective + activeSubjects.size - 1) / activeSubjects.size
                if (activeSubjects.any { s -> filtered.count { it.subject == s } < share }) {
                    Text("Some subjects have fewer questions than an equal share; the rest are filled from other subjects.", fontSize = 12.sp, color = cs.secondary)
                }
            }

            SectionTitle("Difficulty")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = diff == null, onClick = { diff = null }, label = { Text("Mixed") })
                Diff.values().forEach { d ->
                    val n = base.count { it.subject in activeSubjects && it.diff == d }
                    FilterChip(selected = diff == d, onClick = { diff = d }, enabled = n > 0, label = { Text("${d.en} ($n)") })
                }
            }
            if (availTopics.isNotEmpty()) {
                SectionTitle("Topics (optional)")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    availTopics.forEach { t ->
                        FilterChip(selected = t in effTopics, onClick = { topics = if (t in effTopics) effTopics - t else effTopics + t }, label = { Text(t) })
                    }
                }
                Text(if (effTopics.isEmpty()) "All topics included." else "${effTopics.size} topic(s) selected.", fontSize = 12.sp, color = cs.onSurfaceVariant)
            }

            SectionTitle("Practice style")
            Style.values().forEach { s ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { style = s },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.RadioButton(selected = style == s, onClick = { style = s })
                    Column {
                        Text(s.label, fontWeight = FontWeight.SemiBold)
                        Text(s.desc, fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
            SectionTitle("Answer mode")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = instant, onClick = { instant = true }, label = { Text("Instant feedback") })
                FilterChip(selected = !instant, onClick = { instant = false }, label = { Text("Exam feedback") })
            }
            Text(
                if (instant) "Correct answer and explanation appear right after you answer." else "Answers stay hidden until you submit the test.",
                fontSize = 12.sp, color = cs.onSurfaceVariant
            )
            SectionTitle("Timer (total minutes)")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 10, 15, 20, 30, 60, 90, 180).forEach { m ->
                    FilterChip(selected = timer == m, onClick = { timer = m }, label = { Text(if (m == 0) "Off" else "$m") })
                }
            }
            SectionTitle("Order")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Shuffle questions", Modifier.weight(1f)); Switch(shuffleQ, { shuffleQ = it })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Shuffle options", Modifier.weight(1f)); Switch(shuffleO, { shuffleO = it })
            }
            Spacer(Modifier.height(16.dp))
        }
        error?.let { Text(it, Modifier.padding(horizontal = 16.dp), color = cs.error) }
        Button(
            onClick = { if (vm.session != null) confirmReplace = true else startNow() },
            enabled = filtered.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text("Start test ($effective questions)", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
    if (confirmReplace) {
        AlertDialog(
            onDismissRequest = { confirmReplace = false },
            title = { Text("Replace unfinished test?") },
            text = { Text("You have a test in progress. Starting a new one will discard it.") },
            confirmButton = { TextButton(onClick = { confirmReplace = false; startNow() }) { Text("Start new") } },
            dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text("Cancel") } }
        )
    }
}
