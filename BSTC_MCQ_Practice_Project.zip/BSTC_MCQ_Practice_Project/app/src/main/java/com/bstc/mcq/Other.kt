package com.bstc.mcq

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ProgressScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    val st = vm.stats
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Study progress", { vm.pop() })
        if (st.tests == 0) {
            EmptyState("No data yet", "Complete a test and your real statistics will appear here.")
            return@Column
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                ProgressRing(st.accuracy / 100f, "${st.accuracy}%", "Overall accuracy", 170)
            }
            Spacer(Modifier.height(14.dp))
            val best = vm.results.maxOfOrNull { it.scorePct } ?: 0
            val tiles = listOf(
                "Tests attempted" to "${st.tests}", "Questions attempted" to "${st.attempted}",
                "Correct answers" to "${st.correct}", "Incorrect answers" to "${st.wrong}",
                "Best score" to "$best%", "Practice streak" to "${vm.streak} day(s)",
                "Mistakes fixed" to "${st.corrected}", "Bookmarks" to "${vm.bookmarks.size}"
            )
            tiles.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (l, v) -> StatTile(l, v, Modifier.weight(1f), accent = when (l) { "Correct answers" -> GoodGreen; "Incorrect answers" -> cs.error; else -> cs.primary }) }
                }
            }
            SectionTitle("Subject-wise accuracy")
            val subs = Subject.values().toList()
            val vals = subs.map { s -> val p = st.perSubject[s.key]; if (p == null || p.first == 0) 0 else p.second * 100 / p.first }
            BarChart(subs.map { it.en.substringBefore(' ') }, vals, subs.map { it.color })
            Text("0% bars mean you have not attempted that subject yet.", fontSize = 12.sp, color = cs.onSurfaceVariant)
            val recent = vm.results.take(8).reversed()
            if (recent.isNotEmpty()) {
                SectionTitle("Recent test scores")
                BarChart(recent.mapIndexed { i, _ -> "#${i + 1}" }, recent.map { it.scorePct }, listOf(cs.primary, cs.secondary))
                Text("Oldest → newest (last ${recent.size} tests).", fontSize = 12.sp, color = cs.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    val s = vm.settings
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            SectionTitle("Theme")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m -> FilterChip(selected = s.theme == m, onClick = { vm.update(s.copy(theme = m)) }, label = { Text(m.label) }) }
            }
            SectionTitle("Default practice style")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Style.values().forEach { m -> FilterChip(selected = s.style == m, onClick = { vm.update(s.copy(style = m)) }, label = { Text(m.label) }) }
            }
            SectionTitle("Default answer mode")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = s.instant, onClick = { vm.update(s.copy(instant = true)) }, label = { Text("Instant feedback") })
                FilterChip(selected = !s.instant, onClick = { vm.update(s.copy(instant = false)) }, label = { Text("Exam feedback") })
            }
            SectionTitle("Default question count")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10, 20, 25, 30, 50, 100, 0).forEach { n ->
                    FilterChip(selected = s.count == n, onClick = { vm.update(s.copy(count = n)) }, label = { Text(if (n == 0) "All" else "$n") })
                }
            }
            SectionTitle("Default timer (minutes)")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 10, 15, 20, 30, 60, 90, 180).forEach { m ->
                    FilterChip(selected = s.timerMin == m, onClick = { vm.update(s.copy(timerMin = m)) }, label = { Text(if (m == 0) "Off" else "$m") })
                }
            }
            SectionTitle("Test behaviour")
            SwitchRow("Shuffle questions", s.shuffleQ) { vm.update(s.copy(shuffleQ = it)) }
            SwitchRow("Shuffle options", s.shuffleOpts) { vm.update(s.copy(shuffleOpts = it)) }
            SwitchRow("Sound effects", s.sound) { vm.update(s.copy(sound = it)) }
            SwitchRow("Haptic feedback", s.haptic) { vm.update(s.copy(haptic = it)) }
            SectionTitle("Data")
            OutlinedButton(
                onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error)
            ) { Text("Reset progress") }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.push(Screen.About) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("About this app") }
            Spacer(Modifier.height(20.dp))
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset all progress?") },
            text = { Text("This deletes test results, statistics, wrong-question list, streak and any unfinished test. Bookmarks and settings are kept. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { confirmReset = false; vm.resetProgress() }) { Text("Reset", color = cs.error) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 16.sp)
        Switch(value, onChange)
    }
}

@Composable
fun AboutScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    val r = Bank.report
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("About", { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("BSTC MCQ Practice", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("Version 1.0 · Fully offline · No ads · No login · No special permissions", color = cs.onSurfaceVariant)
            SectionTitle("Question bank")
            Text("Loaded questions: ${r.loaded}")
            Subject.values().forEach { Text("• ${it.en}: ${r.perSubject[it] ?: 0}") }
            Text("Skipped invalid records: ${r.skipped}")
            Text("Skipped exact duplicates: ${r.duplicates}")
            SectionTitle("Please note")
            Text(
                "The question bank is a generated practice draft. Please verify important facts against the current official Rajasthan Pre D.El.Ed syllabus and authoritative sources. Static GK does not include current affairs.",
                color = cs.onSurfaceVariant
            )
        }
    }
}
