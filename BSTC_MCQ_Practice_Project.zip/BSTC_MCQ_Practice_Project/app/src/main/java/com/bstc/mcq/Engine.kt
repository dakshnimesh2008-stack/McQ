package com.bstc.mcq

import kotlin.random.Random

class BuildResult(val items: List<PQ>, val note: String?)

object Engine {

    fun filterPool(base: List<Question>, subjects: Set<Subject>, topics: Set<String>, diff: Diff?): List<Question> =
        base.filter { it.subject in subjects && (topics.isEmpty() || it.topic in topics) && (diff == null || it.diff == diff) }

    fun buildTest(cfg: TestConfig, base: List<Question>, rnd: Random = Random.Default): BuildResult {
        val pool = filterPool(base, cfg.subjects, cfg.topics, cfg.difficulty).distinctBy { it.id }
        if (pool.isEmpty()) return BuildResult(emptyList(), "No questions match your selection.")
        val total = if (cfg.count <= 0) pool.size else minOf(cfg.count, pool.size)
        var note: String? = null
        if (cfg.count > pool.size) note = "Only ${pool.size} questions available for this selection."

        val groups = Subject.values().filter { it in cfg.subjects }.associateWith { s ->
            val l = pool.filter { it.subject == s }
            if (cfg.shuffleQ) l.shuffled(rnd) else l
        }.filterValues { it.isNotEmpty() }

        val picked: List<Question> = when {
            groups.size <= 1 || cfg.distribution == Distribution.RANDOM -> {
                val l = if (cfg.shuffleQ) pool.shuffled(rnd) else pool
                l.take(total)
            }
            else -> {
                val subs = groups.keys.toList()
                val quota = HashMap<Subject, Int>()
                if (cfg.distribution == Distribution.PROPORTIONAL) {
                    var used = 0
                    for (s in subs) {
                        val share = (total.toLong() * groups[s]!!.size / pool.size).toInt()
                        quota[s] = minOf(share, groups[s]!!.size); used += quota[s]!!
                    }
                    var left = total - used
                    var guard = 0
                    while (left > 0 && guard++ < 10000) {
                        var progressed = false
                        for (s in subs.sortedByDescending { groups[it]!!.size - quota[it]!! }) {
                            if (left <= 0) break
                            if (quota[s]!! < groups[s]!!.size) { quota[s] = quota[s]!! + 1; left--; progressed = true }
                        }
                        if (!progressed) break
                    }
                } else {
                    for (s in subs) quota[s] = 0
                    var left = total
                    var guard = 0
                    while (left > 0 && guard++ < 100000) {
                        var progressed = false
                        for (s in subs) {
                            if (left <= 0) break
                            if (quota[s]!! < groups[s]!!.size) { quota[s] = quota[s]!! + 1; left--; progressed = true }
                        }
                        if (!progressed) break
                    }
                    val share = total / subs.size
                    if (subs.any { groups[it]!!.size < share }) {
                        note = (note?.plus(" ") ?: "") + "Some subjects have fewer questions than an equal share; the rest were filled from other subjects."
                    }
                }
                subs.flatMap { groups[it]!!.take(quota[it] ?: 0) }
            }
        }
        val ordered = if (cfg.shuffleQ) picked.shuffled(rnd) else picked.sortedWith(compareBy({ it.subject.ordinal }, { it.id }))
        val items = ordered.distinctBy { it.id }.map { q ->
            val order = listOf(0, 1, 2, 3).let { if (cfg.shuffleOpts) it.shuffled(rnd) else it }
            PQ(q, order)
        }
        return BuildResult(items, note)
    }

    fun makeRecord(s: LiveSession, now: Long): ResultRecord {
        var attempted = 0
        var correct = 0
        val per = LinkedHashMap<Subject, IntArray>()
        val items = ArrayList<ResultItem>()
        for (pq in s.items) {
            val sel = s.answers[pq.q.id]
            val arr = per.getOrPut(pq.q.subject) { IntArray(3) }
            arr[0]++
            if (sel != null) {
                attempted++; arr[1]++
                if (sel == pq.q.correct) { correct++; arr[2]++ }
            }
            items.add(ResultItem(pq.q.id, pq.order, sel ?: -1, s.marked.contains(pq.q.id)))
        }
        return ResultRecord(
            now, s.cfg.title, s.items.size, attempted, correct, s.elapsed,
            per.map { SubjectResult(it.key.key, it.value[0], it.value[1], it.value[2]) }, items
        )
    }

    fun fmtTime(sec: Int): String {
        val s = if (sec < 0) 0 else sec
        val h = s / 3600
        val m = (s % 3600) / 60
        val r = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, r) else "%02d:%02d".format(m, r)
    }
}
