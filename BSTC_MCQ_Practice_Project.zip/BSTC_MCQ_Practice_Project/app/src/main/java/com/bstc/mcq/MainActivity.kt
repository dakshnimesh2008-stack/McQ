package com.bstc.mcq

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent { BstcApp() }
    }
}

@Composable
fun BstcApp(vm: AppViewModel = viewModel()) {
    val dark = isDarkFor(vm.settings.theme)
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? ComponentActivity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    BstcTheme(dark) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                val top = vm.top
                if (top !is Screen.Practice && top !is Screen.Home) BackHandler { vm.pop() }
                if (top is Screen.Home) BackHandler(enabled = false) {}
                AnimatedContent(
                    targetState = top,
                    transitionSpec = {
                        val forward = vm.stack.size >= 2 && targetState === vm.stack.last()
                        (slideInHorizontally(tween(260)) { if (forward) it / 4 else -it / 4 } + fadeIn(tween(260))) togetherWith
                            (slideOutHorizontally(tween(200)) { if (forward) -it / 6 else it / 6 } + fadeOut(tween(160)))
                    }, label = "screens"
                ) { screen ->
                    when (screen) {
                        is Screen.Home -> HomeScreen(vm)
                        is Screen.Setup -> SetupScreen(vm, screen)
                        is Screen.Practice -> PracticeScreen(vm)
                        is Screen.Result -> ResultScreen(vm, screen.id)
                        is Screen.Review -> ReviewScreen(vm, screen.id)
                        is Screen.Bookmarks -> QuestionListScreen(vm, false)
                        is Screen.Wrong -> QuestionListScreen(vm, true)
                        is Screen.Progress -> ProgressScreen(vm)
                        is Screen.History -> HistoryScreen(vm)
                        is Screen.Settings -> SettingsScreen(vm)
                        is Screen.About -> AboutScreen(vm)
                    }
                }
                vm.message?.let { m ->
                    AlertDialog(
                        onDismissRequest = { vm.message = null },
                        title = { Text("Heads up") }, text = { Text(m) },
                        confirmButton = { TextButton(onClick = { vm.message = null }) { Text("OK") } }
                    )
                }
            }
        }
    }
}
