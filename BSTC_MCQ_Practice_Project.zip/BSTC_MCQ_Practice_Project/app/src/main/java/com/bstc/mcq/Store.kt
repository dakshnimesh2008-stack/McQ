package com.bstc.mcq

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private inline fun <reified T : Enum<T>> enumOr(s: String?, def: T): T =
    enumValues<T>().firstOrNull { it.name == s } ?: def

/** All user data lives locally in SharedPreferences (no network, no permissions). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("bstc_store", Context.MODE_PRIVATE)

    // ---------- settings ----------
    fun loadSettings(): Settings {
        val d = Settings()
        val j = try { JSONObject(p.getString("settings", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        return Settings(
            theme = enumOr(j.optString("theme"), d.theme),
            style = enumOr(j.optString("style"), d.style),
            instant = j.optBoolean("instant", d.instant),
            count = j.optInt("count", d.count),
            timerMin = j.optInt("timerMin", d.timerMin),
            sound = j.optBoolean("sound", d.sound),
            haptic = j.optBoolean("haptic", d.haptic),
            shuffleQ = j.optBoolean("shuffleQ", d.shuffleQ),
            shuffleOpts = j.optBoolean("shuffleOpts", d.shuffleOpts)
        )
    }

    fun saveSettings(s: Settings) {
        val j = JSONObject()
            .put("theme", s.theme.name).put("style", s.style.name).put("instant", s.instant)
            .put("count", s.count).put("timerMin", s.timerMin).put("sound", s.sound)
            .put("haptic", s.haptic).put("shuffleQ", s.shuffleQ).put("shuffleOpts", s.shuffleOpts)
        p.edit().putString("settings", j.toString()).apply()
    }

    // ---------- id sets ----------
    fun loadSet(key: String): Set<String> = (p.getStringSet(key, emptySet()) ?: emptySet()).toSet()
    fun saveSet(key: String, v: Set<String>) { p.edit().putStringSet(key, HashSet(v)).apply() }

    // ---------- results ----------
    fun loadResults(): List<ResultRecord> {
        val out = ArrayList<ResultRecord>()
        try {
            val arr = JSONArray(p.getString("results", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                try { out.add(recFromJson(arr.getJSONObject(i))) } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
        return out
    }

    fun saveResults(list: List<ResultRecord>) {
        // newest first; keep full detail for the latest 20 only
        val arr = JSONArray()
        list.take(100).forEachIndexed { i, r -> arr.put(recToJson(r, i < 20)) }
        p.edit().putString("results", arr.toString()).apply()
    }

    private fun recToJson(r: ResultRecord, detail: Boolean): JSONObject {
        val subs = JSONArray()
        r.subjects.forEach { subs.put(JSONArray().put(it.key).put(it.total).put(it.attempted).put(it.correct)) }
        val items = JSONArray()
        if (detail) r.items.forEach {
            items.put(JSONArray().put(it.qid).put(JSONArray(it.order)).put(it.selected).put(it.marked))
        }
        return JSONObject().put("id", r.id).put("title", r.title).put("total", r.total)
            .put("attempted", r.attempted).put("correct", r.correct).put("seconds", r.seconds)
            .put("subjects", subs).put("items", items)
    }

    private fun recFromJson(j: JSONObject): ResultRecord {
        val subs = ArrayList<SubjectResult>()
        val sa = j.optJSONArray("subjects") ?: JSONArray()
        for (i in 0 until sa.length()) {
            val a = sa.getJSONArray(i)
            subs.add(SubjectResult(a.getString(0), a.getInt(1), a.getInt(2), a.getInt(3)))
        }
        val items = ArrayList<ResultItem>()
        val ia = j.optJSONArray("items") ?: JSONArray()
        for (i in 0 until ia.length()) {
            val a = ia.getJSONArray(i)
            val oa = a.getJSONArray(1)
            items.add(ResultItem(a.getString(0), (0 until oa.length()).map { oa.getInt(it) }, a.getInt(2), a.getBoolean(3)))
        }
        return ResultRecord(
            j.getLong("id"), j.optString("title", "Test"), j.getInt("total"), j.getInt("attempted"),
            j.getInt("correct"), j.optInt("seconds"), subs, items
        )
    }

    // ---------- stats ----------
    fun loadStats(): Stats {
        return try {
            val j = JSONObject(p.getString("stats", "{}") ?: "{}")
            val per = HashMap<String, Pair<Int, Int>>()
            val po = j.optJSONObject("per") ?: JSONObject()
            po.keys().forEach { k -> val a = po.getJSONArray(k); per[k] = Pair(a.getInt(0), a.getInt(1)) }
            Stats(j.optInt("tests"), j.optInt("attempted"), j.optInt("correct"), j.optInt("corrected"), per)
        } catch (e: Exception) { Stats() }
    }

    fun saveStats(s: Stats) {
        val po = JSONObject()
        s.perSubject.forEach { (k, v) -> po.put(k, JSONArray().put(v.first).put(v.second)) }
        val j = JSONObject().put("tests", s.tests).put("attempted", s.attempted).put("correct", s.correct)
            .put("corrected", s.corrected).put("per", po)
        p.edit().putString("stats", j.toString()).apply()
    }

    // ---------- practice days / streak ----------
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun streak(days: Set<String>): Int {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        if (!days.contains(fmt.format(cal.time))) cal.add(Calendar.DAY_OF_YEAR, -1)
        var s = 0
        while (days.contains(fmt.format(cal.time))) { s++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return s
    }

    // ---------- session ----------
    fun saveSession(s: LiveSession) {
        val c = s.cfg
        val cj = JSONObject().put("title", c.title)
            .put("subjects", JSONArray(c.subjects.map { it.key })).put("topics", JSONArray(c.topics.toList()))
            .put("count", c.count).put("difficulty", c.difficulty?.name ?: "")
            .put("distribution", c.distribution.name).put("timerMin", c.timerMin)
            .put("shuffleQ", c.shuffleQ).put("shuffleOpts", c.shuffleOpts)
            .put("style", c.style.name).put("instant", c.instant).put("source", c.source.name)
        val items = JSONArray()
        s.items.forEach { items.put(JSONArray().put(it.q.id).put(JSONArray(it.order))) }
        val ans = JSONObject()
        s.answers.forEach { (k, v) -> ans.put(k, v) }
        val j = JSONObject().put("cfg", cj).put("items", items).put("answers", ans)
            .put("marked", JSONArray(s.marked.toList())).put("index", s.index).put("elapsed", s.elapsed)
        p.edit().putString("session", j.toString()).apply()
    }

    fun clearSession() { p.edit().remove("session").apply() }

    fun loadSession(): LiveSession? {
        val raw = p.getString("session", null) ?: return null
        return try {
            val j = JSONObject(raw)
            val cj = j.getJSONObject("cfg")
            val sa = cj.getJSONArray("subjects")
            val subs = (0 until sa.length()).mapNotNull { Subject.fromKey(sa.getString(it)) }.toSet()
            val ta = cj.getJSONArray("topics")
            val cfg = TestConfig(
                cj.getString("title"), subs, (0 until ta.length()).map { ta.getString(it) }.toSet(),
                cj.getInt("count"), Diff.values().firstOrNull { it.name == cj.optString("difficulty") },
                enumOr(cj.optString("distribution"), Distribution.RANDOM), cj.getInt("timerMin"),
                cj.getBoolean("shuffleQ"), cj.getBoolean("shuffleOpts"),
                enumOr(cj.optString("style"), Style.CLASSIC), cj.getBoolean("instant"),
                enumOr(cj.optString("source"), Source.NORMAL)
            )
            val ia = j.getJSONArray("items")
            val items = ArrayList<PQ>()
            for (i in 0 until ia.length()) {
                val a = ia.getJSONArray(i)
                val q = Bank.byId[a.getString(0)] ?: continue
                val oa = a.getJSONArray(1)
                val order = (0 until oa.length()).map { oa.getInt(it) }
                if (order.sorted() != listOf(0, 1, 2, 3)) continue
                items.add(PQ(q, order))
            }
            if (items.isEmpty()) return null
            val s = LiveSession(cfg, items)
            val ao = j.getJSONObject("answers")
            ao.keys().forEach { k -> if (Bank.byId.containsKey(k)) s.answers[k] = ao.getInt(k) }
            val ma = j.getJSONArray("marked")
            for (i in 0 until ma.length()) s.marked.add(ma.getString(i))
            s.index = j.optInt("index").coerceIn(0, items.size - 1)
            s.elapsed = j.optInt("elapsed")
            s
        } catch (e: Exception) { null }
    }

    fun resetProgress() {
        p.edit().remove("results").remove("stats").remove("wrong").remove("seen").remove("days").remove("session").apply()
    }
}
