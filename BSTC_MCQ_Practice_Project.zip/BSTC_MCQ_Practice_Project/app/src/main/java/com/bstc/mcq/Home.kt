package com.bstc.mcq

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun presetSetup(vm: AppViewModel, title: String, mode: SetupMode, subjects: Set<Subject>) =
    Screen.Setup(title, mode, subjects, Source.NORMAL, null, null, null, null)

@Composable
fun HomeScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 600.dp
        val cols = if (wide) 2 else 1
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.logo), "BSTC logo", Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("BSTC MCQ Practice", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Rajasthan Pre D.El.Ed · Offline", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    val st = vm.streak
                    if (st > 0) {
                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(cs.secondaryContainer).padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.LocalFireDepartment, null, Modifier.size(18.dp), tint = cs.secondary)
                            Spacer(Modifier.width(4.dp))
                            Text("$st", fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer)
                        }
                    }
                }
            }
            val ses = vm.session
            if (ses != null) {
                item {
                    Card(
                        Modifier.fillMaxWidth().clickable { vm.resume() }, shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.PlayArrow, null, tint = cs.onSecondaryContainer, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Resume unfinished test", fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer)
                                Text(
                                    "${ses.cfg.title} · ${ses.answers.size}/${ses.items.size} answered",
                                    fontSize = 13.sp, color = cs.onSecondaryContainer
                                )
                            }
                        }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { vm.push(presetSetup(vm, "Practice", SetupMode.MULTI, Subject.values().toSet())) },
                        modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp)
                    ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Start Practice", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = {
                                vm.push(Screen.Setup("Mixed Mock Test", SetupMode.MIXED, Subject.values().toSet(), Source.NORMAL, 100, 90, false, Style.CLASSIC))
                            },
                            modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)
                        ) { Icon(Icons.Filled.Timer, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Mixed Mock") }
                        OutlinedButton(
                            onClick = { vm.push(presetSetup(vm, "Custom Test", SetupMode.CUSTOM, Subject.values().toSet())) },
                            modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)
                        ) { Icon(Icons.Filled.Tune, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Custom Test") }
                    }
                }
            }
            item { Text("Subjects", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp)) }
            val subjects = Subject.values().toList()
            items2(subjects.chunked(cols)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { s -> SubjectCard(vm, s, Modifier.weight(1f)) }
                    if (row.size < cols) Spacer(Modifier.weight((cols - row.size).toFloat()))
                }
            }
            item { Text("Your study space", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp)) }
            val links = listOf(
                Triple("Previous Results", Icons.Filled.History, { vm.push(Screen.History) }) to "${vm.results.size} tests",
                Triple("Bookmarked", Icons.Filled.Bookmark, { vm.push(Screen.Bookmarks) }) to "${vm.bookmarks.size} saved",
                Triple("Wrong Questions", Icons.Filled.ErrorOutline, { vm.push(Screen.Wrong) }) to "${vm.wrong.size} to fix",
                Triple("Study Progress", Icons.Filled.BarChart, { vm.push(Screen.Progress) }) to "${vm.stats.accuracy}% accuracy",
                Triple("Settings", Icons.Filled.Settings, { vm.push(Screen.Settings) }) to "Theme, timer, more"
            )
            val lcols = if (wide) 3 else 2
            items2(links.chunked(lcols)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { (t, sub) -> LinkCard(t.first, sub, t.second, Modifier.weight(1f), t.third) }
                    if (row.size < lcols) Spacer(Modifier.weight((lcols - row.size).toFloat()))
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

private fun <T> androidx.compose.foundation.lazy.LazyListScope.items2(list: List<T>, content: @Composable (T) -> Unit) {
    items(list.size) { content(list[it]) }
}

@Composable
private fun LinkCard(title: String, sub: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = cs.primary)
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Text(sub, color = cs.onSurfaceVariant, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun SubjectCard(vm: AppViewModel, s: Subject, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val total = Bank.report.perSubject[s] ?: 0
    val practiced = vm.seen.count { Bank.byId[it]?.subject == s }
    val st = vm.stats.perSubject[s.key]
    val acc = if (st == null || st.first == 0) null else st.second * 100 / st.first
    val frac by animateFloatAsState(if (total == 0) 0f else practiced.toFloat() / total, tween(800), label = "subjprog")
    Card(
        modifier, shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)
    ) {
        Column(Modifier.background(Brush.verticalGradient(listOf(s.color.copy(alpha = 0.20f), Color.Transparent))).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.size(44.dp).clip(CircleShape).background(s.color), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(s.icon, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.en, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(s.hi, color = cs.onSurfaceVariant, fontSize = 12.sp)
                }
                Text("$total Qs", fontWeight = FontWeight.Bold, color = s.color)
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)), color = s.color, trackColor = cs.surface)
            Spacer(Modifier.height(6.dp))
            Text(
                "Practised $practiced / $total" + (if (acc != null) " · Accuracy $acc%" else ""),
                fontSize = 12.sp, color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { vm.push(Screen.Setup(s.en, SetupMode.SINGLE, setOf(s), Source.NORMAL, null, null, null, null)) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), enabled = total > 0,
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = s.color, contentColor = Color.White)
            ) { Text(if (total > 0) "Practice" else "No questions") }
        }
    }
}
