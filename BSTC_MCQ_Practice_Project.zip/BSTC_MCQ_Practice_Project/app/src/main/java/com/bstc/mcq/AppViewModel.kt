package com.bstc.mcq

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

sealed interface Screen {
    object Home : Screen
    data class Setup(
        val title: String, val mode: SetupMode, val subjects: Set<Subject>, val source: Source,
        val count: Int?, val timerMin: Int?, val instant: Boolean?, val style: Style?, val ids: List<String> = emptyList()
    ) : Screen
    object Practice : Screen
    data class Result(val id: Long) : Screen
    data class Review(val id: Long) : Screen
    object Bookmarks : Screen
    object Wrong : Screen
    object Progress : Screen
    object History : Screen
    object Settings : Screen
    object About : Screen
}

class LiveSession(val cfg: TestConfig, val items: List<PQ>) {
    val answers = mutableStateMapOf<String, Int>()
    val marked = mutableStateListOf<String>()
    var index by mutableIntStateOf(0)
    var elapsed by mutableIntStateOf(0)
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var stack by mutableStateOf<List<Screen>>(listOf(Screen.Home))
        private set
    var settings by mutableStateOf(store.loadSettings())
        private set
    var bookmarks by mutableStateOf(store.loadSet("bookmarks"))
        private set
    var wrong by mutableStateOf(store.loadSet("wrong"))
        private set
    var seen by mutableStateOf(store.loadSet("seen"))
        private set
    var days by mutableStateOf(store.loadSet("days"))
        private set
    var results by mutableStateOf(store.loadResults())
        private set
    var stats by mutableStateOf(store.loadStats())
        private set
    var session by mutableStateOf<LiveSession?>(null)
        private set
    var message by mutableStateOf<String?>(null)

    init {
        Bank.load(app)
        // drop ids that no longer exist in the bank
        bookmarks = bookmarks.filter { Bank.byId.containsKey(it) }.toSet()
        wrong = wrong.filter { Bank.byId.containsKey(it) }.toSet()
        session = store.loadSession()
    }

    val top: Screen get() = stack.last()
    val streak: Int get() = store.streak(days)

    // ---------- navigation ----------
    fun push(s: Screen) { stack = stack + s }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun goHome() { stack = listOf(Screen.Home) }

    // ---------- settings ----------
    fun update(s: Settings) { settings = s; store.saveSettings(s) }

    // ---------- bookmarks ----------
    fun toggleBookmark(id: String) {
        bookmarks = if (bookmarks.contains(id)) bookmarks - id else bookmarks + id
        store.saveSet("bookmarks", bookmarks)
    }

    // ---------- starting tests ----------
    fun poolFor(source: Source, ids: List<String> = emptyList()): List<Question> = when (source) {
        Source.NORMAL -> Bank.all
        Source.BOOKMARKS -> bookmarks.mapNotNull { Bank.byId[it] }
        Source.WRONG -> wrong.mapNotNull { Bank.byId[it] }
        Source.IDS -> ids.mapNotNull { Bank.byId[it] }
    }

    /** Returns an error/info message or null if the test started. */
    fun start(cfg: TestConfig, ids: List<String> = emptyList()): String? {
        val res = Engine.buildTest(cfg, poolFor(cfg.source, ids))
        if (res.items.isEmpty()) return res.note ?: "No questions available."
        val s = LiveSession(cfg, res.items)
        session = s
        store.saveSession(s)
        stack = stack.filter { it !is Screen.Setup && it !is Screen.Practice } + Screen.Practice
        message = res.note
        return null
    }

    fun resume() {
        if (session != null) stack = stack.filter { it !is Screen.Practice } + Screen.Practice
    }

    fun discardSession() { session = null; store.clearSession() }

    // ---------- in-test actions ----------
    fun answer(qid: String, orig: Int) {
        val s = session ?: return
        if (s.cfg.instant && s.answers.containsKey(qid)) return
        s.answers[qid] = orig
        store.saveSession(s)
    }

    fun clearAnswer(qid: String) {
        val s = session ?: return
        if (s.cfg.instant) return
        s.answers.remove(qid)
        store.saveSession(s)
    }

    fun toggleMark(qid: String) {
        val s = session ?: return
        if (s.marked.contains(qid)) s.marked.remove(qid) else s.marked.add(qid)
        store.saveSession(s)
    }

    fun goto(i: Int) {
        val s = session ?: return
        s.index = i.coerceIn(0, s.items.size - 1)
        store.saveSession(s)
    }

    /** Called once per second while a practice screen is visible. Returns true if time has run out. */
    fun tick(): Boolean {
        val s = session ?: return false
        s.elapsed += 1
        if (s.elapsed % 5 == 0) store.saveSession(s)
        return s.cfg.timerMin > 0 && s.elapsed >= s.cfg.timerMin * 60
    }

    fun saveNow() { session?.let { store.saveSession(it) } }

    fun submit() {
        val s = session ?: return
        val rec = Engine.makeRecord(s, System.currentTimeMillis())
        var st = stats
        val per = st.perSubject.toMutableMap()
        for (r in rec.subjects) {
            val old = per[r.key] ?: Pair(0, 0)
            per[r.key] = Pair(old.first + r.attempted, old.second + r.correct)
        }
        var corrected = st.corrected
        var w = wrong
        var sn = seen
        for (pq in s.items) {
            val sel = s.answers[pq.q.id] ?: continue
            sn = sn + pq.q.id
            if (sel == pq.q.correct) {
                if (w.contains(pq.q.id)) { w = w - pq.q.id; corrected++ }
            } else {
                w = w + pq.q.id
            }
        }
        st = Stats(st.tests + 1, st.attempted + rec.attempted, st.correct + rec.correct, corrected, per)
        stats = st; store.saveStats(st)
        wrong = w; store.saveSet("wrong", w)
        seen = sn; store.saveSet("seen", sn)
        days = days + store.today(); store.saveSet("days", days)
        results = listOf(rec) + results
        store.saveResults(results)
        session = null
        store.clearSession()
        stack = listOf(Screen.Home, Screen.Result(rec.id))
    }

    fun removeWrong(id: String) {
        wrong = wrong - id
        store.saveSet("wrong", wrong)
    }

    fun resetProgress() {
        store.resetProgress()
        results = emptyList(); stats = Stats(); wrong = emptySet(); seen = emptySet(); days = emptySet()
        session = null
        goHome()
    }
}
